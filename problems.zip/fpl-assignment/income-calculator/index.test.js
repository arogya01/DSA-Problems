const InsuranceCalculator = require('./index.js');

describe('InsuranceCalculator', () => {
  let calc;

  beforeAll(() => {
    calc = new InsuranceCalculator();
  });

  test('throws TypeError when income is undefined', () => {
    expect(() => calc.calculate(undefined)).toThrow(TypeError);
  });

  test('throws TypeError when income is null', () => {
    expect(() => calc.calculate(null)).toThrow(TypeError);
  });

  test('throws TypeError when income is NaN', () => {
    expect(() => calc.calculate(NaN)).toThrow(TypeError);
  });

  test("tests for infinity and -infinity", () => {
    expect(() => calc.calculate(Infinity)).toThrow(TypeError);
    expect(() => calc.calculate(-Infinity)).toThrow(TypeError);
  }
  );

  test('throws RangeError when income is negative', () => {
    expect(() => calc.calculate(-1)).toThrow(RangeError);
  });

  test('calculates correctly at 0 income', () => {
    expect(calc.calculate(0)).toBeCloseTo(0);
  });

  test('calculates at lower boundary 10000', () => {
    expect(calc.calculate(10000)).toBeCloseTo(10000 * 0.365);
  });

  test('calculates just above 10000', () => {
    const income = 10000.01;
    expect(calc.calculate(income)).toBeCloseTo((income - 10000) * 0.2 + 35600);
  });

  test('calculates at middle boundary 30000', () => {
    expect(calc.calculate(30000)).toBeCloseTo((30000 - 10000) * 0.2 + 35600);
  });

  test('calculates just above 30000', () => {
    const income = 30000.5;
    expect(calc.calculate(income)).toBeCloseTo((income - 30000) * 0.1 + 76500);
  });

  test('calculates at upper boundary 60000', () => {
    expect(calc.calculate(60000)).toBeCloseTo((60000 - 30000) * 0.1 + 76500);
  });

  test('calculates just above 60000', () => {
    const income = 60001;
    expect(calc.calculate(income)).toBeCloseTo((income - 60000) * 0.02 + 105600);
  });
  
  test('calculates mid low bracket', () => {
    expect(calc.calculate(5000)).toBeCloseTo(5000 * 0.365);
  });

  test('calculates mid middle bracket', () => {
    expect(calc.calculate(20000)).toBeCloseTo((20000 - 10000) * 0.2 + 35600);
  });

  test('calculates mid upper-middle bracket', () => {
    expect(calc.calculate(45000)).toBeCloseTo((45000 - 30000) * 0.1 + 76500);
  });

  test('calculates high bracket', () => {
    expect(calc.calculate(100000)).toBeCloseTo((100000 - 60000) * 0.02 + 105600);
  });

  
  test('throws if no strategy matches (e.g., custom empty strategies)', () => {
    const emptyCalc = new InsuranceCalculator([]);
    expect(() => emptyCalc.calculate(1000)).toThrow(Error);
  });
});