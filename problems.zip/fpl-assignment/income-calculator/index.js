
class LowIncomeStrategy {
  isApplicable(income) {
    return income >= 0 && income <= 10000;
  }
  calculate(income) {
    return income * 0.365;
  }
  }
  
  class MiddleIncomeStrategy {
  isApplicable(income) {
    return income > 10000 && income <= 30000;
  }
  calculate(income) {
    return (income - 10000) * 0.2 + 35600;
  }
  }
  
  class UpperMiddleIncomeStrategy {
  isApplicable(income) {
    return income > 30000 && income <= 60000;
  }
  calculate(income) {
    return (income - 30000) * 0.1 + 76500;
  }
  }
  
  class HighIncomeStrategy {
  isApplicable(income) {
    // Check if income is finite and greater than 60000
    return Number.isFinite(income) && income > 60000;
  }
  calculate(income) {
    return (income - 60000) * 0.02 + 105600;
  }
  }
  
  class InsuranceCalculator {
  constructor(strategies) {
    this.strategies = strategies || [
    new LowIncomeStrategy(),
    new MiddleIncomeStrategy(),
    new UpperMiddleIncomeStrategy(),
    new HighIncomeStrategy(),
    ];
  }
  
  calculate(income) {    
    if (income === undefined || income === null || typeof income !== 'number' || !Number.isFinite(income)) {
      throw new TypeError('Income must be a finite number');
    }
    
    if (income < 0) {
    throw new RangeError('Income cannot be negative');
    }
  
    const strategy = this.strategies.find(s => s.isApplicable(income));
  
    if (!strategy) {

    throw new Error(`No applicable strategy found for income: ${income}`);
    }
    
    return strategy.calculate(income);
  }
  }
  
module.exports = InsuranceCalculator;