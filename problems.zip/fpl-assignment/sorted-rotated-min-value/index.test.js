const findMin = require('./index.js');

describe('findMin', () => {
    // Standard cases from problem examples
    describe('Standard cases', () => {
        test('Rotated 3 times: [3,4,5,1,2] should return 1', () => {
            expect(findMin([3, 4, 5, 1, 2])).toBe(1);
        });

        test('Rotated 4 times: [4,5,6,7,0,1,2] should return 0', () => {
            expect(findMin([4, 5, 6, 7, 0, 1, 2])).toBe(0);
        });

        test('Not rotated or rotated n times: [11,13,15,17] should return 11', () => {
            expect(findMin([11, 13, 15, 17])).toBe(11);
        });
    });

    // Edge cases
    describe('Edge cases', () => {
        test('Single element: [1] should return 1', () => {
            expect(findMin([1])).toBe(1);
        });

        test('Two elements, rotated: [2,1] should return 1', () => {
            expect(findMin([2, 1])).toBe(1);
        });

        test('Two elements, not rotated: [1,2] should return 1', () => {
            expect(findMin([1, 2])).toBe(1);
        });

        test('Not rotated, larger array: [1,2,3,4,5] should return 1', () => {
            expect(findMin([1, 2, 3, 4, 5])).toBe(1);
        });

        test('Rotated, min in middle: [5,1,2,3,4] should return 1', () => {
            expect(findMin([5, 1, 2, 3, 4])).toBe(1);
        });

        test('Rotated, min at end: [1,2,3,4,5,6,0] should return 0', () => {
            expect(findMin([1, 2, 3, 4, 5, 6, 0])).toBe(0);
        });

        test('Negative numbers: [0,1,2,-4,-3,-2,-1] should return -4', () => {
            expect(findMin([0, 1, 2, -4, -3, -2, -1])).toBe(-4);
        });

        test('All negative, not rotated: [-5,-4,-3,-2,-1] should return -5', () => {
            expect(findMin([-5, -4, -3, -2, -1])).toBe(-5);
        });

        test('All negative, rotated: [-1,-5,-4,-3,-2] should return -5', () => {
            expect(findMin([-1, -5, -4, -3, -2])).toBe(-5);
        });

        test('Large range within constraints: [5000,-5000,0,1000] should return -5000', () => {
            expect(findMin([5000, -5000, 0, 1000])).toBe(-5000);
        });
    });

    // Robustness tests for invalid inputs
    describe('Robustness tests', () => {
        test('Null input should throw error', () => {
            expect(() => findMin(null)).toThrow("Input must be a non-null, non-undefined array");
        });

        test('Undefined input should throw error', () => {
            expect(() => findMin(undefined)).toThrow("Input must be a non-null, non-undefined array");
        });

        test('Empty array should throw error', () => {
            expect(() => findMin([])).toThrow("Array must not be empty");
        });

        test('Non-numeric elements should throw error', () => {
            expect(() => findMin([1, "2", 3])).toThrow("All elements must be integers");
        });

        test('Non-integer numbers should throw error', () => {
            expect(() => findMin([1, 2.5, 3])).toThrow("All elements must be integers");
        });
    });
});