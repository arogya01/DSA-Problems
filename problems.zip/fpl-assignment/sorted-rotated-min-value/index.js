function findMin(nums) {
    if (!Array.isArray(nums) || nums === null || nums === undefined) {
        throw new Error("Input must be a non-null, non-undefined array");
    }
    if (nums.length === 0) {
        throw new Error("Array must not be empty");
    }
    if (!nums.every(num => typeof num === 'number' && Number.isInteger(num))) {
        throw new Error("All elements must be integers");
    }

    if (nums.length === 1) return nums[0];

    let left = 0;
    let right = nums.length - 1;

    if (nums[left] <= nums[right]) return nums[left];

    while (left < right) {
        const mid = left + Math.floor((right - left) / 2);
        if (nums[mid] > nums[right]) {
            left = mid + 1;
        } else {
            right = mid;
        }
    }
    return nums[left];
}

module.exports =  findMin;